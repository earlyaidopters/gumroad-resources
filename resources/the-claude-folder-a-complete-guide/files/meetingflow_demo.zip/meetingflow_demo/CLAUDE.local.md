# Personal Overrides

- I prefer verbose test output: always run with --verbose flag
- When generating emails, match my casual tone. No "Dear" or "Sincerely"
- Default timezone for my meetings: America/New_York
