#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
[[ "$(uname -s)" == Darwin ]] || { echo 'Relay Voice requires macOS.' >&2; exit 1; }
for tool in node npm python3 swiftc codesign; do
  command -v "$tool" >/dev/null || { echo "Missing prerequisite: $tool. See README.md." >&2; exit 1; }
done
node -e 'const [a,b]=process.versions.node.split(".").map(Number);if(a<22||(a===22&&b<12))process.exit(1)' || { echo 'Node.js 22.12 or newer is required.' >&2; exit 1; }
python3 -c 'import sys; assert sys.version_info >= (3,10)' || { echo 'Python 3.10 or newer is required.' >&2; exit 1; }
config_dir="$HOME/.config/relay-voice"
umask 077
mkdir -p "$config_dir"
if [[ ! -e "$config_dir/providers.env" ]]; then
  cp "$root/.env.example" "$config_dir/providers.env"
  chmod 600 "$config_dir/providers.env"
fi
npm --prefix "$root/app/electron" ci
"$root/app/build-electron.sh"
echo 'Built Relay Voice. Add your own provider keys to ~/.config/relay-voice/providers.env, then run ./app/launch.sh.'
