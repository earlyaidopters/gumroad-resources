# Third-party notices

The generated Relay Voice icon is included with this project. Google, Gmail and Firecrawl marks identify integrations and remain the property of their owners; they do not imply endorsement. Asset sources and hashes are retained in `app/electron/ui/services/PROVENANCE.json`.

The bundled Marked parser retains its license in `app/electron/ui/vendor/marked.LICENSE`. Electron and packaging dependencies retain their licenses in their distributions. The project MIT license does not replace third-party license or trademark terms.
