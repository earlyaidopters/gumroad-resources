# Verification and first-run acceptance

The source release is based on Relay Voice 0.10.14. The release process runs backend, Electron and native checks, packages the app and verifies its signature/resources. Provider tests use synthetic or mocked data. A passing test suite does not establish physical voice insertion on every Mac.

After setting up your own credentials:

1. Launch one copy of Relay Voice and approve the normal macOS permissions.
2. Focus an empty unsent text field. Hold Option and say: “Write a friendly two-sentence thank-you note for helping me film today.” Release. Check that the spoken words appear in that field; do not send.
3. Ask for a simple public web fact. Check that the answer opens once, Copy works and source links point to the cited pages.
4. If Gmail is configured, ask for one message you are comfortable testing with. Confirm the selected account is correct and inspect the answer privately.
5. Minimize, expand and drag the voice bar. Relaunch and confirm its position persists.
6. Cancel a request with Escape; confirm no late result inserts into a different field.

No timing, quality or universal insertion claim is made by this checklist. Provider errors, quota limits, account permissions and macOS editor behavior remain environment-dependent.
