# Privacy and local data

This repository contains source, synthetic tests, prompts and app assets. It includes no configured accounts, OAuth credentials, API keys, recordings, real mailbox content or private build conversations.

- Provider keys belong in `~/.config/relay-voice/providers.env`. The bridge also supports an explicit `RELAY_ENV_FILE` and legacy `~/.env`; it only looks up named configuration values.
- Google authentication remains in your Google Workspace CLI configuration and operating-system keychain.
- The native helper stores settings and request history under `~/Library/Application Support/Relay Voice/`. Electron stores its window placement and profile in its own application-support directory. History can contain dictated words and requested answers, so treat that folder as private.
- Audio is recorded temporarily and sent to Gemini for transcription and intent detection. Web requests go to Firecrawl. Relevant email text is supplied to Gemini only for requested mailbox work.
- The desktop app previews drafts without saving or sending them. A legacy backend draft adapter exists for environments with a separate `gws-mail` wrapper, but the desktop helper does not expose it.
- No analytics or telemetry service is configured by this project. Provider services process the data you send under their own terms.

Do not attach raw logs, history, audio or provider responses to public issues. Describe bugs using invented text and remove private details from screenshots first.
