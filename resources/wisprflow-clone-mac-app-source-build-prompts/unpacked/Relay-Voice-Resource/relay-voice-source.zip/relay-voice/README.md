# Relay Voice

<img src="app/assets/relay-voice-icon.png" alt="Relay Voice icon" width="110">

**Hold Option. Speak. Release to write or research.**

Relay Voice is a local macOS voice app with a draggable voice bar, automatic dictation, web research and optional Gmail assistance. This is the original combined-workflow app shown in the Astra versus Sol video, with portable configuration for your own machine. The separate Astra-only and Sol-only comparison apps are not included.

[**Use this template**](https://github.com/promptadvisers/relay-voice/generate) · [**View the walkthrough**](https://relay-voice-build-plan.markkashef.chatgpt.site/) · [**Read the complete build prompt**](prompts/BUILD-WITH-PHASES.md) · [**Read the comparison prompt**](prompts/COMPARISON-PROMPT.md)

## What it does

- **Dictation:** hold Option, speak, then release to insert text into the field you were using. Escape cancels.
- **Research:** ask for information from the web. Relay uses Firecrawl and shows an answer with source links and an inspectable tool history.
- **Gmail assistance:** request email context from an account you connect. The desktop app reads email and can show an unsaved reply preview; it does not send email.
- **A movable voice bar:** drag it, minimize it and keep its position between launches.
- **Local history:** revisit completed requests, copy answers and clear history.

The desktop UI and helper run locally. Speech and relevant request context are sent to Gemini. Web queries go to Firecrawl. If you request Gmail assistance, relevant email context may be sent to Gemini to produce the answer. This is not offline transcription.

## Start here

You need a Mac, Xcode Command Line Tools, Node.js 22.12 or newer, Python 3.10 or newer, and your own Gemini API key. A Firecrawl key enables web research. Google Workspace CLI setup is optional for Gmail.

```bash
git clone https://github.com/promptadvisers/relay-voice.git
cd relay-voice
./scripts/setup.sh
```

The setup script checks your tools, creates an empty private provider configuration if one does not already exist, installs the pinned Electron dependencies and builds the app. It does not log into any service or grant macOS permissions.

Edit `~/.config/relay-voice/providers.env` with a local text editor:

```dotenv
GOOGLE_API_KEY=your_own_gemini_key
FIRECRAWL_API_KEY=your_own_firecrawl_key
```

Use [Google AI Studio](https://aistudio.google.com/api-keys) for Gemini and [Firecrawl](https://www.firecrawl.dev/) for web research. API usage is billed by those providers. Never paste keys into a GitHub issue, commit or screenshot.

Then launch:

```bash
./app/launch.sh
```

The built application is `app/dist/electron/Relay Voice.app`. Keep it at one stable location; moving or rebuilding it can require macOS permissions to be approved again. This source build is locally signed, not a notarized downloadable release.

### macOS permissions

Open Relay's Settings and allow Microphone for recording and Accessibility for insertion. macOS may also require Input Monitoring for the global shortcut. Approve the app in System Settings using the normal macOS controls. The app cannot approve these on your behalf.

For a first test, focus an empty, unsent text field and dictate: “Write a friendly two-sentence thank-you note for helping me film today.” Confirm that the words land in the intended field before using it for important text. Secure fields and some custom editors may block insertion; Copy remains available.

## Optional: connect Gmail

Install the [Google Workspace CLI](https://github.com/googleworkspace/cli) and follow its OAuth setup instructions. For example:

```bash
npm install -g @googleworkspace/cli
gws auth setup
gws auth login --readonly -s gmail
```

The setup command requires `gcloud`; the CLI documentation also provides a manual Google Cloud Console route. Use a Google Cloud project and OAuth credentials that you control.

Relay's **Primary** account uses the CLI's default configuration. It invokes the vendor CLI directly; no private account wrapper is required. If the executable is somewhere unusual, add its absolute location as `RELAY_GWS_BIN` in your private provider configuration.

For another account, authenticate with a separate configuration directory:

```bash
GOOGLE_WORKSPACE_CLI_CONFIG_DIR="$HOME/.config/relay-voice/google-workspace/work" gws auth setup
GOOGLE_WORKSPACE_CLI_CONFIG_DIR="$HOME/.config/relay-voice/google-workspace/work" gws auth login --readonly -s gmail
```

Select **Work** in Relay. **Personal** works the same way with the final directory named `personal`. Custom directories can be set with `RELAY_GWS_CONFIG_PRIMARY`, `RELAY_GWS_CONFIG_WORK` and `RELAY_GWS_CONFIG_PERSONAL` in the private provider file. The app removes inherited bearer credentials for explicitly selected profiles so they cannot silently override that account.

## Build and check

```bash
./scripts/check.sh
./app/build-electron.sh
```

Checks exercise dictation routing, source handling, account isolation, cancellation, native insertion guards, Markdown safety, window state and the helper protocol using synthetic fixtures. They do not prove that your microphone, Accessibility permission, provider quota or destination editor works. See [verification and manual acceptance](docs/VERIFICATION.md).

Default speech and text model: `gemini-3.5-flash-lite`, matching the filmed app. Model availability depends on your provider access. The existing model field can override it; record any change when comparing results.

## Files

| Path | Purpose |
|---|---|
| `app/electron/` | Desktop UI, window management and packaging |
| `app/native/` | Swift recording, shortcut and insertion helper |
| `app/backend.py` | Gemini, Firecrawl and Gmail bridge |
| `prompts/BUILD-WITH-PHASES.md` | Reusable phased build recipe |
| `prompts/COMPARISON-PROMPT.md` | Shared starting specification from the comparison |
| `docs/PRIVACY.md` | Data flow and local storage |

## About this release

Based on the original Relay Voice 0.10.14 app. Public-release changes replace machine-specific Google CLI routing and account labels, add setup documentation and keep credentials outside the repository. The original app was developed across multiple model-assisted phases and later repairs; the repository is not a claim of a single-model or one-prompt build.

The prompts have private paths and account labels replaced with portable examples. Tool names and model assignments describe the recorded workflow and may require adaptation to your environment.

MIT license for the project code. Third-party dependencies and provider marks keep their own licenses and terms; see [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).
