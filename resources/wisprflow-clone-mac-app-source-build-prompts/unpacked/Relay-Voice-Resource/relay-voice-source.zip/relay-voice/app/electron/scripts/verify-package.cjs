'use strict';
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { createHash } = require('node:crypto');
const { execFileSync } = require('node:child_process');
const appRoot = path.resolve(__dirname, '../..');
const bundle = path.join(appRoot, 'dist/electron/Relay Voice.app');
async function main() {
  const resources = path.join(bundle, 'Contents/Resources');
  const plist = JSON.parse(execFileSync('/usr/bin/plutil', ['-convert', 'json', '-o', '-', path.join(bundle, 'Contents/Info.plist')], { encoding: 'utf8' }));
  assert.equal(plist.CFBundleIdentifier, 'com.relayvoice.electron');
  assert.equal(plist.CFBundleExecutable, 'Relay Voice');
  assert.ok(plist.NSMicrophoneUsageDescription.includes('Option'));
  assert.ok(plist.ElectronAsarIntegrity);
  assert.ok(fs.statSync(path.join(resources, plist.CFBundleIconFile)).size > 10000);
  assert.ok(fs.statSync(path.join(resources, 'relay-voice-icon.png')).size > 10000);
  fs.accessSync(path.join(resources, 'native/relay-voice-helper'), fs.constants.X_OK);
  const hash = file => createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  assert.equal(hash(path.join(resources, 'native/backend.py')), hash(path.join(appRoot, 'backend.py')), 'Packaged backend must be the real current bridge');
  const { listPackage, extractFile } = await import('@electron/asar');
  const asarPath = path.join(resources, 'app.asar');
  const files = listPackage(asarPath);
  for (const required of ['/main.cjs', '/preload.cjs', '/lib/bridge.cjs', '/ui/index.html', '/ui/overlay.html', '/ui/markdown.js', '/ui/vendor/marked.js', '/ui/vendor/marked.LICENSE']) assert.ok(files.includes(required), required);
  assert.equal(createHash('sha256').update(extractFile(asarPath, 'ui/vendor/marked.js')).digest('hex'), hash(path.join(appRoot, 'electron/node_modules/marked/lib/marked.esm.js')), 'Packaged Markdown lexer matches pinned dependency');
  const providerAssets = JSON.parse(extractFile(asarPath, 'ui/services/PROVENANCE.json').toString());
  for (const asset of providerAssets) {
    assert.equal(createHash('sha256').update(extractFile(asarPath, `ui/services/${asset.file}`)).digest('hex'), asset.sha256, `Official provider asset: ${asset.file}`);
  }
  assert.ok(!files.some(file => /node_modules|tests|fixture|\.env|backend\.py/.test(file)), 'No fixture, secrets, native resources, or development dependencies in asar');
  const pkg = JSON.parse(extractFile(asarPath, 'package.json').toString()); assert.ok(!pkg.devDependencies && !pkg.scripts);
  const { getCurrentFuseWire, FuseV1Options, FuseState } = await import('@electron/fuses');
  const fuses = await getCurrentFuseWire(bundle);
  for (const option of ['RunAsNode', 'EnableNodeOptionsEnvironmentVariable', 'EnableNodeCliInspectArguments', 'GrantFileProtocolExtraPrivileges']) assert.equal(fuses[FuseV1Options[option]], FuseState.DISABLE, option);
  for (const option of ['EnableEmbeddedAsarIntegrityValidation', 'OnlyLoadAppFromAsar']) assert.equal(fuses[FuseV1Options[option]], FuseState.ENABLE, option);
  execFileSync('/usr/bin/codesign', ['--verify', '--deep', '--strict', bundle]);
  execFileSync('/usr/bin/codesign', ['--verify', '--strict', path.join(resources, 'native/relay-voice-helper')]);
  const entitlements = JSON.parse(execFileSync('/usr/bin/plutil', ['-convert', 'json', '-o', '-', '-'], { input: execFileSync('/usr/bin/codesign', ['-d', '--entitlements', ':-', bundle], { stdio: ['pipe', 'pipe', 'ignore'] }), encoding: 'utf8' }));
  assert.equal(entitlements['com.apple.security.cs.disable-library-validation'], true, 'Local ad-hoc Electron requires its framework load entitlement');
  console.log(JSON.stringify({ package: bundle, version: pkg.version, architecture: process.arch, asarFiles: files.length, backendSHA256: hash(path.join(resources, 'native/backend.py')), helperSHA256: hash(path.join(resources, 'native/relay-voice-helper')), signature: 'ad-hoc, hardened runtime with local library-validation exception; deep strict verification passed', launched: false }, null, 2));
}
main().catch(error => { console.error(error.message); process.exitCode = 1; });
