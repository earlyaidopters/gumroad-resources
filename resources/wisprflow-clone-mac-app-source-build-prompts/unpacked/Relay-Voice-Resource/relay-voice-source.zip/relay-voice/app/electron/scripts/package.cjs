'use strict';
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const { execFileSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const appRoot = path.resolve(root, '..');

async function main() {
  if (process.platform !== 'darwin') throw new Error('Package Relay Voice on macOS so its native helper matches the host.');
  const destination = path.join(appRoot, 'dist/electron/Relay Voice.app');
  const running = execFileSync('/bin/ps', ['-axo', 'command='], { encoding: 'utf8' });
  if (running.split('\n').some(line => line.startsWith(path.join(destination, 'Contents/MacOS/')))) throw new Error('Quit the packaged Electron app before rebuilding it.');
  execFileSync(path.join(appRoot, 'build-helper.sh'), [], { stdio: 'inherit' });
  const temp = await fs.mkdtemp(path.join(os.tmpdir(), 'relay-electron-package-'));
  try {
    const source = path.join(temp, 'source'), native = path.join(temp, 'native');
    await fs.mkdir(source); await fs.mkdir(native);
    for (const name of ['main.cjs', 'preload.cjs', 'lib', 'ui']) await fs.cp(path.join(root, name), path.join(source, name), { recursive: true });
    const pkg = JSON.parse(await fs.readFile(path.join(root, 'package.json'), 'utf8'));
    delete pkg.devDependencies; delete pkg.scripts;
    await fs.writeFile(path.join(source, 'package.json'), JSON.stringify(pkg, null, 2));
    for (const name of ['relay-voice-helper', 'backend.py']) await fs.copyFile(path.join(appRoot, 'dist/helper', name), path.join(native, name));
    const { packager } = await import('@electron/packager');
    const outputs = await packager({ dir: source, name: 'Relay Voice', executableName: 'Relay Voice', appBundleId: 'com.relayvoice.electron', appVersion: pkg.version, buildVersion: pkg.version, platform: 'darwin', arch: process.arch, electronVersion: require('electron/package.json').version, out: path.join(temp, 'output'), asar: true, asarIntegrityDigest: true, overwrite: false, prune: false, icon: path.join(appRoot, 'assets/relay-voice.icns'), extraResource: [native, path.join(appRoot, 'assets/relay-voice-icon.png')], extendInfo: { NSMicrophoneUsageDescription: 'Relay Voice records your microphone while you hold Option to transcribe your speech.', LSApplicationCategoryType: 'public.app-category.productivity' } });
    const bundle = path.join(outputs[0], 'Relay Voice.app');
    const { flipFuses, FuseVersion, FuseV1Options } = await import('@electron/fuses');
    await flipFuses(bundle, { version: FuseVersion.V1, [FuseV1Options.RunAsNode]: false, [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false, [FuseV1Options.EnableNodeCliInspectArguments]: false, [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true, [FuseV1Options.OnlyLoadAppFromAsar]: true, [FuseV1Options.GrantFileProtocolExtraPrivileges]: false });
    const { sign } = await import('@electron/osx-sign');
    // Local ad-hoc builds have no Team ID. Permit their bundled Electron framework
    // under hardened runtime; a future Developer ID release must revisit this exception.
    await sign({ app: bundle, platform: 'darwin', identity: '-', identityValidation: false, preAutoEntitlements: false, preEmbedProvisioningProfile: false, optionsForFile: file => ({ hardenedRuntime: true, timestamp: 'none', entitlements: file.endsWith('relay-voice-helper') ? ['com.apple.security.device.audio-input'] : ['com.apple.security.cs.allow-jit', 'com.apple.security.cs.disable-library-validation', 'com.apple.security.device.audio-input'] }) });
    execFileSync('/usr/bin/codesign', ['--verify', '--deep', '--strict', bundle], { stdio: 'inherit' });
    await fs.mkdir(path.dirname(destination), { recursive: true });
    try {
      await fs.access(destination);
      const archive = path.join(appRoot, 'dist/archives', `Relay Voice-${Date.now()}.zip`);
      await fs.mkdir(path.dirname(archive), { recursive: true });
      // Keep a recoverable backup without leaving another launchable app bundle.
      execFileSync('/usr/bin/ditto', ['-c', '-k', '--sequesterRsrc', '--keepParent', destination, archive]);
      execFileSync('/usr/bin/unzip', ['-tq', archive], { stdio: 'ignore' });
      await fs.rm(destination, { recursive: true });
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
    await fs.rename(bundle, destination);
    console.log(`Packaged: ${destination}`);
    execFileSync(process.execPath, [path.join(__dirname, 'verify-package.cjs')], { stdio: 'inherit' });
  } finally { await fs.rm(temp, { recursive: true, force: true }); }
}
main().catch(error => { console.error(`Packaging failed: ${error.message}`); process.exitCode = 1; });
