# Relay Voice app icon

Created by main Codex chat using the built-in image-generation tool on 2026-09-27. Original generated file retained. Project copy: relay-voice-icon.png. Packaging may resize and convert to ICNS.

Prompt: polished macOS app icon for Relay Voice; forest-charcoal rounded-square tile, centered mint-green sound-wave bars, restrained satin/glass finish, subtle dimensional edges, large simple symbol readable at small sizes, no text or existing brand logo, transparent exterior corners.
